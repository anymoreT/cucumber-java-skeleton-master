package com.tom.utils.dto;

public class TypeValueEntry {
	public String 类型;
	public String 值;
}
