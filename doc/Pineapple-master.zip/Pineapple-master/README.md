# Pineapple
Java Cucumber自动化框架，用于测试Dubbo，http，mq，jdbc的自动化测试。可以自己定义写关键字，也可以直接用关键字开发
目前暂时没有集成spring，后面会出现一个spring版本。
支持的几大功能
1. Dubbo
2. http get和post请求
3. 环境参数切换
4. Rabbit Mq
5. 数据库操作（mysql ,oracle）

若有改进意见和关键字需要新增的，欢迎邮件联系我

Tom Luo

aboard123@hotmail.com

